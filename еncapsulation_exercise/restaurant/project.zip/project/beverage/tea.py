from project.beverage.beverage import Beverage


class Tea(Beverage):
    pass
